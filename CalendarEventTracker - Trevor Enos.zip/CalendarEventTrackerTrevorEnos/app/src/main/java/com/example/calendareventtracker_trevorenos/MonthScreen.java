package com.example.calendareventtracker_trevorenos;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.NumberPicker;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.MaterialCalendarView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;

public class MonthScreen extends AppCompatActivity {

    private long lastClickTime = 0;
    private String lastSelectedDate = "";

    private MaterialCalendarView calendarView;
    private Database dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_month_screen);

        dbHelper = new Database(this);
        calendarView = findViewById(R.id.calendarView);

        Calendar today = Calendar.getInstance();
        lastSelectedDate = today.get(Calendar.DAY_OF_MONTH) + "/" +
                (today.get(Calendar.MONTH) + 1) + "/" +
                today.get(Calendar.YEAR);

        setupCalendar();
        setupSpinners();
        setupYearButton();
    }

    // Handles date selection and opens the day screen on double tap
    private void setupCalendar() {
        calendarView.setOnDateChangedListener((widget, date, selected) -> {

            long currentTime = System.currentTimeMillis();

            int year = date.getYear();
            int month = date.getMonth();
            int day = date.getDay();

            String selectedDate = String.format(
                    Locale.US,
                    "%04d-%02d-%02d",
                    year,
                    month + 1,
                    day
            );

            String tappedDate = day + "/" + (month + 1) + "/" + year;

            if (tappedDate.equals(lastSelectedDate)
                    && currentTime - lastClickTime < 500) {

                Intent intent = new Intent(
                        MonthScreen.this,
                        DayScreen.class
                );

                intent.putExtra("SELECTED_DATE", selectedDate);
                intent.putExtra("YEAR", year);
                intent.putExtra("MONTH", month + 1);
                intent.putExtra("DAY", day);

                startActivity(intent);
            }

            lastClickTime = currentTime;
            lastSelectedDate = tappedDate;
        });
    }

    // Sets up both dropdown menus
    private void setupSpinners() {

        Spinner manageSpinner = findViewById(R.id.spinner_manage_events);
        Spinner settingsSpinner = findViewById(R.id.spinner_settings);

        String[] manageItems = {
                "Manage Events",
                "Add Event",
                "Delete Event",
                "Edit Event",
                "Event History"
        };

        String[] settingsItems = {
                "Settings",
                "User Settings"
        };

        setupSpinner(manageSpinner, manageItems);
        setupSpinner(settingsSpinner, settingsItems);

        manageSpinner.setOnItemSelectedListener(
                new android.widget.AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(
                            android.widget.AdapterView<?> parent,
                            android.view.View view,
                            int position,
                            long id) {

                        if (position == 0) {
                            return;
                        }

                        String selected =
                                parent.getItemAtPosition(position).toString();

                        switch (selected) {
                            case "Add Event":
                                openScreen(AddEvent.class);
                                break;

                            case "Delete Event":
                                openScreen(DeleteEvent.class);
                                break;

                            case "Edit Event":
                                openScreen(UpdateEvent.class);
                                break;

                            case "Event History":
                                openScreen(EventHistory.class);
                                break;
                        }
                    }

                    @Override
                    public void onNothingSelected(
                            android.widget.AdapterView<?> parent) {
                    }
                });

        settingsSpinner.setOnItemSelectedListener(
                new android.widget.AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(
                            android.widget.AdapterView<?> parent,
                            android.view.View view,
                            int position,
                            long id) {

                        if (position == 0) {
                            return;
                        }

                        String selected =
                                parent.getItemAtPosition(position).toString();

                        if ("User Settings".equals(selected)) {
                            openScreen(SettingScreen.class);
                        }
                    }

                    @Override
                    public void onNothingSelected(
                            android.widget.AdapterView<?> parent) {
                    }
                });
    }

    // Year picker button
    private void setupYearButton() {

        Button yearButton = findViewById(R.id.button2);

        yearButton.setOnClickListener(v -> showYearPicker());
    }

    private void showYearPicker() {

        NumberPicker yearPicker = new NumberPicker(this);

        Calendar calendar = Calendar.getInstance();
        int currentYear = calendar.get(Calendar.YEAR);

        yearPicker.setMinValue(currentYear - 10);
        yearPicker.setMaxValue(currentYear + 10);
        yearPicker.setValue(currentYear);
        yearPicker.setWrapSelectorWheel(false);

        new AlertDialog.Builder(this)
                .setTitle("Select Calendar Year")
                .setView(yearPicker)
                .setPositiveButton("Apply", (dialog, which) -> {

                    int selectedYear = yearPicker.getValue();

                    Calendar targetDate = Calendar.getInstance();
                    targetDate.set(
                            selectedYear,
                            Calendar.JANUARY,
                            1
                    );

                    calendarView.setCurrentDate(
                            CalendarDay.from(targetDate.getTime())
                    );
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void openScreen(Class<?> activityClass) {
        startActivity(new Intent(this, activityClass));
    }

    private void setupSpinner(
            Spinner spinner,
            String[] items) {

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        items
                );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinner.setAdapter(adapter);
    }

    @Override
    protected void onResume() {
        super.onResume();

        new Thread(this::loadEventsOnCalendarAsync).start();
    }

    // Adds dots to dates that contain events
    private void loadEventsOnCalendarAsync() {

        HashSet<CalendarDay> eventDates = new HashSet<>();

        Cursor cursor = dbHelper.getAllEvents();

        SimpleDateFormat formatter =
                new SimpleDateFormat(
                        "yyyy-MM-dd",
                        Locale.getDefault()
                );

        if (cursor != null) {
            try {

                if (cursor.moveToFirst()) {

                    int dateColumn =
                            cursor.getColumnIndex("COL_DATE");

                    if (dateColumn == -1) {
                        dateColumn = 2;
                    }

                    do {

                        String dateString =
                                cursor.getString(dateColumn);

                        if (dateString == null ||
                                dateString.isEmpty()) {
                            continue;
                        }

                        try {

                            Date date =
                                    formatter.parse(dateString);

                            if (date != null) {
                                eventDates.add(
                                        CalendarDay.from(date)
                                );
                            }

                        } catch (ParseException e) {
                            e.printStackTrace();
                        }

                    } while (cursor.moveToNext());
                }

            } finally {
                cursor.close();
            }
        }

        runOnUiThread(() -> {
            if (calendarView != null) {
                calendarView.addDecorator(
                        new CalendarEvents(
                                Color.RED,
                                eventDates
                        )
                );
            }
        });
    }
}

