package com.example.calendareventtracker_trevorenos;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class EventHistory extends AppCompatActivity {

    private LinearLayout historyContainer;
    private Database dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_history);

        historyContainer = findViewById(R.id.historyContainer);
        dbHelper = new Database(this);

        ImageButton backButton = findViewById(R.id.backButton);
        //back button
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(EventHistory.this, MonthScreen.class);

                startActivity(intent);
                finish();
            }
        });
    }
    //updates event list
    @Override
    protected void onResume() {
        super.onResume();
        displayAllEvents();
    }

    private void displayAllEvents() {
        historyContainer.removeAllViews();

        Cursor cursor = dbHelper.getAllEvents();
        if (cursor == null) return;

        try {
            while (cursor.moveToNext()) {
                //grabs event details
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String title = cursor.getString(cursor.getColumnIndexOrThrow("title"));
                String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
                String description = cursor.getString(cursor.getColumnIndexOrThrow("description"));
                String time = cursor.getString(cursor.getColumnIndexOrThrow("time"));
                //block for showing details
                String cardContent = "ID: " + id + "\n" +
                        "Title: " + title + "\n" +
                        "Date: " + date + "\n" +
                        "Time: " + time + "\n" +
                        "Description: " + description;

                TextView eventCard = new TextView(this);
                eventCard.setText(cardContent);
                eventCard.setTextColor(Color.WHITE);
                eventCard.setTextSize(15);
                eventCard.setPadding(24, 20, 24, 20);
                eventCard.setBackgroundResource(R.drawable.event_card_background);

                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );
                params.setMargins(0, 0, 0, 16);
                eventCard.setLayoutParams(params);

                historyContainer.addView(eventCard);
            }
        } finally {
            cursor.close();
        }
    }
}
