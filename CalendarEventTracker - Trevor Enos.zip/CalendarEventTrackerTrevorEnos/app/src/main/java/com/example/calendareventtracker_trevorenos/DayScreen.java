package com.example.calendareventtracker_trevorenos;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class DayScreen extends AppCompatActivity {

    private static final int HOUR_ROW_HEIGHT_DP = 80;
    private static final String DEFAULT_DATE = "2026-06-30";

    private RelativeLayout eventsPlacementArea;
    private Database dbHelper;
    private String targetDate = DEFAULT_DATE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_day_screen);

        eventsPlacementArea = findViewById(R.id.eventsPlacementArea);
        TextView headerText = findViewById(R.id.toolbar_day_text);
        ImageButton backButton = findViewById(R.id.backButton);

        dbHelper = new Database(this);

        String selectedDate = getIntent().getStringExtra("SELECTED_DATE");

        if (selectedDate != null && !selectedDate.isEmpty()) {
            targetDate = selectedDate;
            updateHeader(headerText, selectedDate);
        }
        //back button
        backButton.setOnClickListener(v -> {
            startActivity(new Intent(DayScreen.this, MonthScreen.class));
            finish();
        });

        loadAndRenderEvents();
    }
    //updates header with values grabbed by date
    private void updateHeader(TextView headerText, String dateString) {
        try {
            SimpleDateFormat parser =
                    new SimpleDateFormat("yyyy-MM-dd", Locale.US);

            Date date = parser.parse(dateString);

            if (date == null) {
                return;
            }

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);

            String dayName =
                    new SimpleDateFormat("EEEE", Locale.US).format(date);

            String monthName =
                    new SimpleDateFormat("MMMM", Locale.US).format(date);

            int dayNumber = calendar.get(Calendar.DAY_OF_MONTH);

            headerText.setText(dayName + " " + monthName + " " + dayNumber);

        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
    //loads events on this day
    private void loadAndRenderEvents() {
        eventsPlacementArea.removeAllViews();

        Cursor cursor = dbHelper.getEventsForDate(targetDate);

        if (cursor == null) {
            return;
        }

        float density = getResources().getDisplayMetrics().density;
        int rowHeight = (int) (HOUR_ROW_HEIGHT_DP * density);

        try {
            while (cursor.moveToNext()) {

                String title =
                        cursor.getString(cursor.getColumnIndexOrThrow("title"));

                String description =
                        cursor.getString(cursor.getColumnIndexOrThrow("description"));

                String time =
                        cursor.getString(cursor.getColumnIndexOrThrow("time"));

                float hourOffset = parseTimeToHourOffset(time);

                if (hourOffset >= 0) {
                    addEventCard(title, description, hourOffset, rowHeight);
                }
            }
        } finally {
            cursor.close();
        }
    }
    //places a card for the event
    private void addEventCard(String title,
                              String description,
                              float hourOffset,
                              int rowHeight) {

        TextView eventCard = new TextView(this);

        eventCard.setText(title + "\n" + description);
        eventCard.setTextColor(Color.WHITE);
        eventCard.setTextSize(14);
        eventCard.setPadding(16, 12, 16, 12);
        eventCard.setBackgroundResource(R.drawable.event_card_background);

        RelativeLayout.LayoutParams params =
                new RelativeLayout.LayoutParams(
                        RelativeLayout.LayoutParams.MATCH_PARENT,
                        RelativeLayout.LayoutParams.WRAP_CONTENT
                );

        params.topMargin = (int) (hourOffset * rowHeight);
        params.leftMargin = 8;
        params.rightMargin = 8;

        eventsPlacementArea.addView(eventCard, params);
    }
    //time check for adding events to the scheduled time
    private float parseTimeToHourOffset(String timeString) {

        if (timeString == null || timeString.isEmpty()) {
            return -1;
        }

        try {
            String[] parts = timeString.trim().split(":");

            int hour = Integer.parseInt(parts[0]);

            if (timeString.toLowerCase().contains("pm") && hour < 12) {
                hour += 12;
            }

            if (timeString.toLowerCase().contains("am") && hour == 12) {
                hour = 0;
            }

            String minuteText = parts[1].replaceAll("[^0-9]", "");
            int minutes = minuteText.isEmpty() ? 0 : Integer.parseInt(minuteText);

            return hour + (minutes / 60f);

        } catch (Exception e) {
            return -1;
        }
    }
}
