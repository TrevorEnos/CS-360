package com.example.calendareventtracker_trevorenos;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class NewAccount extends AppCompatActivity {

    private EditText etRegisterEmail, etRegisterPassword;
    private Button btnCreateAccount, btnBackToLogin;
    private Database dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_account);

        dbHelper = new Database(this);

        etRegisterEmail = findViewById(R.id.etRegisterEmail);
        etRegisterPassword = findViewById(R.id.etRegisterPassword);
        btnCreateAccount = findViewById(R.id.btnCreateAccount);
        btnBackToLogin = findViewById(R.id.btnBackToLogin);

        //new account creation
        btnCreateAccount.setOnClickListener(v -> {
            String email = etRegisterEmail.getText().toString().trim();
            String password = etRegisterPassword.getText().toString().trim();

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(NewAccount.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            if (password.length() < 6) {
                Toast.makeText(NewAccount.this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean isRegistered = dbHelper.registerUser(email, password);

            if (isRegistered) {
                Toast.makeText(NewAccount.this, "Account created successfully!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(NewAccount.this, "Email already registered!", Toast.LENGTH_SHORT).show();
            }
        });

        //back button
        btnBackToLogin.setOnClickListener(v -> finish());
    }
}
