package com.example.calendareventtracker_trevorenos;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ResetPassword extends AppCompatActivity {

    private EditText etResetEmail, etNewPassword;
    private Button btnResetPassword, btnCancelReset;
    private Database dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);

        dbHelper = new Database(this);

        etResetEmail = findViewById(R.id.etResetEmail);
        etNewPassword = findViewById(R.id.etNewPassword);
        btnResetPassword = findViewById(R.id.btnResetPassword);
        btnCancelReset = findViewById(R.id.btnCancelReset);

        //reset password
        btnResetPassword.setOnClickListener(v -> {
            String email = etResetEmail.getText().toString().trim();
            String newPassword = etNewPassword.getText().toString().trim();

            if (email.isEmpty() || newPassword.isEmpty()) {
                Toast.makeText(ResetPassword.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            if (newPassword.length() < 6) {
                Toast.makeText(ResetPassword.this, "Password must be at least 6 characters long", Toast.LENGTH_SHORT).show();
                return;
            }

            //updates password
            boolean isUpdated = dbHelper.updatePassword(email, newPassword);

            if (isUpdated) {
                Toast.makeText(ResetPassword.this, "Password updated successfully!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(ResetPassword.this, "Failed to update! Email address not found.", Toast.LENGTH_LONG).show();
            }
        });

        //back button
        btnCancelReset.setOnClickListener(v -> finish());
    }
}
