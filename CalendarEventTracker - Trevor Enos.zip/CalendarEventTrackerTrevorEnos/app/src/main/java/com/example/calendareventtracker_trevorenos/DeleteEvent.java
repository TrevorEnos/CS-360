package com.example.calendareventtracker_trevorenos;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class DeleteEvent extends AppCompatActivity {
    EditText etId;
    Button btnDelete;
    Database dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_event);

        dbHelper = new Database(this);
        etId = findViewById(R.id.etDeleteId);
        btnDelete = findViewById(R.id.btnDelete);

        //deletes event
        btnDelete.setOnClickListener(v -> {
            String id = etId.getText().toString().trim();

            if (id.isEmpty()) {
                Toast.makeText(this, "Please enter an ID", Toast.LENGTH_SHORT).show();
                return;
            }

            int deletedRows = dbHelper.deleteEvent(id);
            if (deletedRows > 0) {
                Toast.makeText(this, "Event Deleted!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "No Event found with that ID", Toast.LENGTH_SHORT).show();
            }
        });
        //back button
        ImageButton backButton = findViewById(R.id.backButton);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(DeleteEvent.this, MonthScreen.class);

                startActivity(intent);
                finish();
            }
        });
    }
}