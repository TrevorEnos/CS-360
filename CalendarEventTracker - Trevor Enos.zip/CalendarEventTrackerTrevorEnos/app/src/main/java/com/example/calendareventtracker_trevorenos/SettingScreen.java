package com.example.calendareventtracker_trevorenos;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SettingScreen extends AppCompatActivity {

    private Switch smsNotificationSwitch;
    private Button btnLogout;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting_screen);

        sharedPreferences = getSharedPreferences("AppSettings", Context.MODE_PRIVATE);

        smsNotificationSwitch = findViewById(R.id.smsNotificationSwitch);
        btnLogout = findViewById(R.id.btnLogout);

        smsNotificationSwitch.setChecked(sharedPreferences.getBoolean("SMS_ENABLED", false));

        //sms toggle
        smsNotificationSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            sharedPreferences.edit().putBoolean("SMS_ENABLED", isChecked).apply();

            String msg;
            if (isChecked) {
                msg = "SMS Alerts Enabled";
                checkAndRequestNotificationPermission();
            } else {
                msg = "SMS Alerts Disabled";
            }

            Toast.makeText(SettingScreen.this, msg, Toast.LENGTH_SHORT).show();
        });


        //logout
        btnLogout.setOnClickListener(v -> {
            Toast.makeText(SettingScreen.this, "Logged Out Successfully", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(SettingScreen.this, UserLogin.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
        //back button
        ImageButton backButton = findViewById(R.id.backButton);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(SettingScreen.this, MonthScreen.class);

                startActivity(intent);
                finish();
            }
        });
    }
    private static final int REQUEST_NOTIFICATION_PERMISSION = 101;
    //permission request
    private void checkAndRequestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        REQUEST_NOTIFICATION_PERMISSION);
            }
        }
    }
    //display access
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_NOTIFICATION_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Notification permission granted!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Alerts blocked. Enable them in System Settings.", Toast.LENGTH_LONG).show();
            }
        }
    }

}

