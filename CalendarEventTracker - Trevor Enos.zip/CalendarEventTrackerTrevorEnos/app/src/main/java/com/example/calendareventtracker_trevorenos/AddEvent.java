package com.example.calendareventtracker_trevorenos;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
public class AddEvent extends AppCompatActivity {
    EditText etId, etTitle, etDate, etDesc, etTime;
    Button btnSave;
    Database dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);


        dbHelper = new Database(this);
        etId = findViewById(R.id.etEventId);
        etTitle = findViewById(R.id.etTitle);
        etDate = findViewById(R.id.etDate);
        etDesc = findViewById(R.id.etDesc);
        etTime = findViewById(R.id.etTime);
        btnSave = findViewById(R.id.btnSave);

        //calendar popup
        etDate.setFocusable(false);
        etDate.setClickable(true);
        etDate.setOnClickListener(v -> {
            java.util.Calendar calendar = java.util.Calendar.getInstance();
            int year = calendar.get(java.util.Calendar.YEAR);
            int month = calendar.get(java.util.Calendar.MONTH);
            int day = calendar.get(java.util.Calendar.DAY_OF_MONTH);

            android.app.DatePickerDialog datePickerDialog = new android.app.DatePickerDialog(
                    AddEvent.this,
                    (view, selectedYear, selectedMonth, selectedDay) -> {
                        //date formatter
                        String formattedDate = String.format(java.util.Locale.getDefault(),
                                "%04d-%02d-%02d", selectedYear, (selectedMonth + 1), selectedDay);
                        etDate.setText(formattedDate);
                    },
                    year, month, day
            );
            datePickerDialog.show();
        });
        //save button
        btnSave.setOnClickListener(v -> {
            String id = etId.getText().toString().trim();
            String title = etTitle.getText().toString().trim();
            String date = etDate.getText().toString().trim();
            String desc = etDesc.getText().toString().trim();
            String time = etTime.getText().toString().trim();

            if (id.isEmpty() || title.isEmpty() || date.isEmpty()) {
                Toast.makeText(this, "Please fill required fields", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean isInserted = dbHelper.addEvent(id, title, date, desc, time);

            if (isInserted) {
                scheduleNotification(title, desc, date, time);
                Toast.makeText(this, "Event Added Successfully!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Insertion Failed! ID might be taken.", Toast.LENGTH_SHORT).show();
            }
        });


        //back button
        ImageButton backButton = findViewById(R.id.backButton);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(AddEvent.this, MonthScreen.class);

                startActivity(intent);
                finish();
            }
        });
    }
    //enables notifications for events
    private void scheduleNotification(String title, String desc, String dateStr, String timeStr) {
        try {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US);
            java.util.Date date = sdf.parse(dateStr + " " + timeStr);

            if (date == null) return;
            long triggerTimeMs = date.getTime();

            Intent intent = new Intent(this, NotificationReceiver.class);
            intent.putExtra("TITLE", title);
            intent.putExtra("DESC", desc);

            int requestCode = (int) (triggerTimeMs / 1000);

            android.app.PendingIntent pendingIntent = android.app.PendingIntent.getBroadcast(
                    this, requestCode, intent, android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE);

            android.app.AlarmManager alarmManager = (android.app.AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (alarmManager != null) {
                alarmManager.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, triggerTimeMs, pendingIntent);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
