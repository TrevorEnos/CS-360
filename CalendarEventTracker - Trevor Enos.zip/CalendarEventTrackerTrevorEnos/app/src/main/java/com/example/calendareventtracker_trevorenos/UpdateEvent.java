package com.example.calendareventtracker_trevorenos;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class UpdateEvent extends AppCompatActivity {
    EditText etId, etTitle, etDate, etDesc, etTime;
    Button btnUpdate;
    Database dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_event);

        dbHelper = new Database(this);
        etId = findViewById(R.id.etUpdateId);
        etTitle = findViewById(R.id.etUpdateTitle);
        etDate = findViewById(R.id.etUpdateDate);
        etDesc = findViewById(R.id.etUpdateDesc);
        etTime = findViewById(R.id.etUpdateTime);
        btnUpdate = findViewById(R.id.btnUpdate);

        //calendar pop
        etDate.setFocusable(false);
        etDate.setClickable(true);
        etDate.setOnClickListener(v -> {
            java.util.Calendar calendar = java.util.Calendar.getInstance();
            int year = calendar.get(java.util.Calendar.YEAR);
            int month = calendar.get(java.util.Calendar.MONTH);
            int day = calendar.get(java.util.Calendar.DAY_OF_MONTH);

            android.app.DatePickerDialog datePickerDialog = new android.app.DatePickerDialog(
                    UpdateEvent.this,
                    (view, selectedYear, selectedMonth, selectedDay) -> {
                        //date formatter
                        String formattedDate = String.format(java.util.Locale.getDefault(),
                                "%04d-%02d-%02d", selectedYear, (selectedMonth + 1), selectedDay);
                        etDate.setText(formattedDate);
                    },
                    year, month, day
            );
            datePickerDialog.show();
        });
        //update button
        btnUpdate.setOnClickListener(v -> {
            String id = etId.getText().toString().trim();
            String title = etTitle.getText().toString().trim();
            String date = etDate.getText().toString().trim();
            String desc = etDesc.getText().toString().trim();
            String time = etTime.getText().toString().trim();

            if (id.isEmpty()) {
                Toast.makeText(this, "ID is required", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean isUpdated = dbHelper.updateEvent(id, title, date, desc, time);
            if (isUpdated) {
                Toast.makeText(this, "Event Updated!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Update Failed. Check ID.", Toast.LENGTH_SHORT).show();
            }
        });
        //back button
        ImageButton backButton = findViewById(R.id.backButton);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(UpdateEvent.this, MonthScreen.class);

                startActivity(intent);
                finish();
            }
        });
    }
}
