package com.example.calendareventtracker_trevorenos;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class UserLogin extends AppCompatActivity {

    private EditText editTextTextEmailAddress;
    private EditText editTextTextPassword;
    private Database dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button button = findViewById(R.id.button);
        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button btnResetPassword = findViewById(R.id.btnResetPassword);
        dbHelper = new Database(this);
        editTextTextEmailAddress = findViewById(R.id.editTextTextEmailAddress);
        editTextTextPassword = findViewById(R.id.editTextTextPassword);

        //new user
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UserLogin.this, NewAccount.class);
                startActivity(intent);
            }
        });

        //login
        buttonLogin.setOnClickListener(v -> {
            String email = editTextTextEmailAddress.getText().toString().trim();
            String password = editTextTextPassword.getText().toString().trim();

            //field checks
            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(UserLogin.this, "Please fill in all login fields", Toast.LENGTH_SHORT).show();
                return;
            }

            //check for account
            boolean isValidUser = dbHelper.checkUserLogin(email, password);

            if (isValidUser) {
                Toast.makeText(UserLogin.this, "Login Successful!", Toast.LENGTH_SHORT).show();

                //signs in
                Intent intent = new Intent(UserLogin.this, MonthScreen.class);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(UserLogin.this, "Invalid credentials. Please try again.", Toast.LENGTH_LONG).show();
            }
        });
        //reset password
        btnResetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UserLogin.this, ResetPassword.class);
                startActivity(intent);
            }
        });
    }
}
