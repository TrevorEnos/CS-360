package com.example.calendareventtracker_trevorenos;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Database extends SQLiteOpenHelper {
    //database fields
    private static final String DATABASE_NAME = "EventTracker.db";
    private static final int DATABASE_VERSION = 2;

    private static final String TABLE_EVENTS = "events_table";
    private static final String COL_ID = "id";
    private static final String COL_TITLE = "title";
    private static final String COL_DATE = "date";
    private static final String COL_DESCRIPTION = "description";
    private static final String COL_TIME = "time";

    private static final String TABLE_USERS = "users_table";
    private static final String COL_USER_ID = "user_id";
    private static final String COL_EMAIL = "email";
    private static final String COL_PASSWORD = "password";



    public Database(Context context) {//DATABASE ESTABLISHED
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //event table
        String createTable = "CREATE TABLE " + TABLE_EVENTS + " (" +
                COL_ID + " INTEGER PRIMARY KEY, " +
                COL_TITLE + " TEXT, " +
                COL_DATE + " TEXT, " +
                COL_DESCRIPTION + " TEXT, " +
                COL_TIME + " TEXT);";
        db.execSQL(createTable);

        //account table
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_EMAIL + " TEXT UNIQUE, " +
                COL_PASSWORD + " TEXT);";
        db.execSQL(createUsersTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    //add
    public boolean addEvent(String id, String title, String date, String description, String time) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(COL_ID, id);
        contentValues.put(COL_TITLE, title);
        contentValues.put(COL_DATE, date);
        contentValues.put(COL_DESCRIPTION, description);
        contentValues.put(COL_TIME, time);

        long result = db.insert(TABLE_EVENTS, null, contentValues);
        return result != -1;
    }


    //update
    public boolean updateEvent(String id, String title, String date, String description, String time) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_TITLE, title);
        contentValues.put(COL_DATE, date);
        contentValues.put(COL_DESCRIPTION, description);
        contentValues.put(COL_TIME, time);

        int result = db.update(TABLE_EVENTS, contentValues, COL_ID + " = ?", new String[]{id});
        return result > 0;
    }

    //delete
    public Integer deleteEvent(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_EVENTS, COL_ID + " = ?", new String[]{id});
    }

    //event grabber
    public Cursor getAllEvents() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_EVENTS, null);
    }

    //event grabber for a given date
    public Cursor getEventsForDate(String date) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_EVENTS + " WHERE " + COL_DATE + " = ?";

        return db.rawQuery(query, new String[]{date});
    }

    //account creation
    public boolean registerUser(String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_EMAIL, email.trim().toLowerCase());
        contentValues.put(COL_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, contentValues);
        return result != -1;
    }

    //validate login
    public boolean checkUserLogin(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT * FROM " + TABLE_USERS + " WHERE " + COL_EMAIL + " = ? AND " + COL_PASSWORD + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{email.trim().toLowerCase(), password});

        int count = cursor.getCount();
        cursor.close();

        return count > 0;
    }

    //reset user password
    public boolean updatePassword(String email, String newPassword) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_PASSWORD, newPassword);

        int result = db.update(TABLE_USERS, contentValues, COL_EMAIL + " = ?", new String[]{email.trim().toLowerCase()});
        return result > 0;
    }
}





